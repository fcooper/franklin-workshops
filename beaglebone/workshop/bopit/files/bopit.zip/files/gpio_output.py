#!/usr/bin/python

# Texas Instruments Created Library
import workshop

# External Helper Libraries
#import Adafruit GPIO library with alias
import Adafruit_BBIO.GPIO as GPIO

#Standard Python Library
import time


# Set P9_46 Pinmux to GPIO
## PUT YOUR CODE HERE ##

# Call GPIO.setup and configure P9_46 as an output
## PUT YOUR CODE HERE ##


while True:
    # Set P9_46 HIGH as a GPIO output
    ## PUT YOUR CODE HERE ##
    time.sleep(2)
    # Set P9_46 LOW as a GPIO output
    ## PUT YOUR CODE HERE ##
    time.sleep(2)