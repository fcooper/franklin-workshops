#!/usr/bin/python

# Texas Instruments Created Library
import workshop

# External Helper Libraries
#import Adafruit ADC library with alias
import Adafruit_BBIO.ADC as ADC

#Standard Python Library
import time


# Call ADC Setup (Must be done only once)
## PUT YOUR CODE HERE ##

while True:
    # Read ADC pin (P9_36) value
    ## PUT YOUR CODE HERE ##
 
    # Output ADC value
    ## PUT YOUR CODE HERE ##

    # Convert ADC digital value to analog (voltage) value. Max analog value is 1.8V
    ## PUT YOUR CODE HERE ##

    # Output analog (voltage) value
    ## PUT YOUR CODE HERE ##

    time.sleep(1)