#!/usr/bin/python

# Texas Instruments Created Library
import workshop

# External Helper Libraries
#import Adafruit GPIO library with alias GPIO
## PUT YOUR CODE HERE ##

#Standard Python Library
import time

# Use workshop.setPinMux to set "P9_29" to "gpio" mode.
## PUT YOUR CODE HERE ##

# Call GPIO.setup and configure "P9_29" as an input with a pull down resistor
## PUT YOUR CODE HERE ##


while True:
    # Print "Button Pressed" when the button has been pressed
    ## PUT YOUR CODE HERE ##
        ## PUT YOUR CODE HERE ##
